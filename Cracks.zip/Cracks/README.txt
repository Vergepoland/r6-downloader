Instructions:
1) Add an exclusion to your folder for the Siege version you downloaded (IMPORTANT!!, otherwise it will delete the crack files and the game won't launch)
2) Depending on your version, open CPlay.ini/CODEX.ini/uplay_r2.ini with Notepad and change GAMENAME to something unique and USERNAME
3) Run the game by double-clicking RainbowSix.exe or any other exe you find (read below)
(NOT RainbowSix_BE.exe OR ANY .exe.manifest FILES!!!)

Don't forget to join the Discord server: https://discord.gg/JGA9WPF4K8

Thanks for:
acidicoala to make Saves working
Rat431 for his "ColdPlay" Uplay emulator
CODEX and Plaza for their Uplay Saves emulator
Goldberg for his Steam and Uplay Emulator
Lungu for custom defaultargs.dll, updated RainbowSix.bat and repacking the Cracks

Last updated: 26/10/2024