To install, just drag and drop the files inside the Siege folder

Works for any season before Y5S1 - Void Edge (cant fully confirm)
Alternative to downgrading drivers

For questions, contact me on Discord: dla19

Credits:
https://github.com/Sporif/dxvk-async